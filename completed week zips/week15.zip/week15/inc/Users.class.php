<?php

// class to handle interaction with the users table
class Users {
	
    // property to hold our data from our user
    var $userData = array();
    // property to hold errors
    var $errors = array();
    // property for holding a reference to a database connection so we can reuse it
    var $db = null;

    function __construct() {
        // create a connection to our database
        $this->db = new PDO('mysql:host=localhost;dbname=wdv441_2021;charset=utf8', 
            'wdv441_user', 'wdv441_2021');           
    }
    
    // takes a keyed array and sets our internal data representation to the array
    function set($dataArray) {
        $this->userData = $dataArray;
        
        //var_dump($this->userData, "test");
    }

    // santize the data in the passed array, return the array
    function sanitize($dataArray) {
        // sanitize data based on rules
			$dataArray["userName"] = filter_var($dataArray["userName"], FILTER_SANITIZE_STRING);
			$dataArray["password"] = filter_var($dataArray["password"], FILTER_SANITIZE_STRING);
			$dataArray["userLevel"] = filter_var($dataArray["userLevel"], FILTER_SANITIZE_STRING);   
        return $dataArray;
    }
    
    // load a user based on an id
    function load($userID) {
        // flag to track if the user was loaded
        $isLoaded = false;

        // load from database
        // create a prepared statement (secure programming)
        $stmt = $this->db->prepare("SELECT * FROM users WHERE userID = ?");
        
        // execute the prepared statement passing in the id of the user we 
        // want to load
        $stmt->execute(array($userID));

        // check to see if we loaded the user
        if ($stmt->rowCount() == 1) {
            // if we did load the user, fetch the data as a keyed array
            $dataArray = $stmt->fetch(PDO::FETCH_ASSOC);
            //var_dump($dataArray);
            
            // set the data to our internal property            
            $this->set($dataArray);
                        
            // set the success flag to true
            $isLoaded = true;
        }
        
        //var_dump($stmt->rowCount());
        
        // return success or failure
        return $isLoaded;
    }
    
    // save a user (inserts and updates)
    function save() {
        // create a flag to track if the save was successful
        $isSaved = false;
		//determines if username is taken and flags it
		//
		$userAvailable = true;
		$userName = $this->userData['userName'];
		$stmt = $this->db->prepare("SELECT * FROM users WHERE userName = ?");

		// execute the prepared statement passing in the id of the user we 
		// want to load
		$stmt->execute(array($userName));

		// check to see loaded user
		if ($stmt->rowCount() >= 1) {
			// if we did load the user, set flag
			$userAvailable = false;
		}
		//
		// determine if insert or update based on userID
        // save data from userData property to database
		if ($userAvailable) {
			//hashes password before insertion
			//$this->userData['password'] = $this->hashPassword($this->userData['password']);
			
			if (empty($this->userData['userID'])) {
				// create a prepared statement to insert data into the table
				$stmt = $this->db->prepare(
					"INSERT INTO users
						(userName, password, userLevel) 
					 VALUES (?, ?, ?)");

				// execute the insert statement, passing in the data to insert
				$isSaved = $stmt->execute(array(
						$this->userData['userName'],
						$this->userData['password'],
						$this->userData['userLevel'],
					)
				);

				// if the execute returned true, then store the new id back into our 
				// data property
				if ($isSaved) {
					$this->userData['userID'] = $this->db->lastInsertId();
				}
			} else { 
				// if this is an update of an existing record, create a prepared update 
				// statement
				$stmt = $this->db->prepare(
					"UPDATE users SET 
						userName = ?,
						password = ?,
						userLevel = ?,
					WHERE userID = ?"
				);

				// execute the update statement, passing in the data to update
				$isSaved = $stmt->execute(array(
						$this->userData['userName'],
						$this->userData['password'],
						$this->userData['userLevel'],
						$this->userData['userID'],
					)
				);            
			}
		}else{
			$this->errors['userName'] = "Username Taken";
			$isSaved = false;
		}
                        
        // return the success flage
        return $isSaved;
    }

	//updates user
	function update(){
		// create a flag to track if the save was successful
        $isSaved = false;
		//determines if username is taken and flags it
		//
		$userAvailable = true;
		$userName = $this->userData['userName'];
		$stmt = $this->db->prepare("SELECT * FROM users WHERE userName = ?");

		// execute the prepared statement passing in the id of the user we 
		// want to load
		$stmt->execute(array($userName));
		$dataArray = $stmt->fetch(PDO::FETCH_ASSOC);
		// check to see loaded user
		if ($stmt->rowCount() >= 1 && $dataArray['userName'] != $this->userData['userName']) {
			// if we did load the user, set flag
			$userAvailable = false;
		}
		if ($userAvailable) {
			// if this is an update of an existing record, create a prepared update 
			// statement
			$stmt = $this->db->prepare(
				"UPDATE users SET 
					userName = ?,
					password = ?,
					userLevel = ?,
				WHERE userID = ?"
			);

			// execute the update statement, passing in the data to update
			$isSaved = $stmt->execute(array(
					$this->userData['userName'],
					$this->userData['password'],
					$this->userData['userLevel'],
					$this->userData['userID'],
				)
			
			);
			var_dump($this->userData);

 
		}else{
			$this->errors['userName'] = "Username Taken";
			$isSaved = false;
		}
                        
        // return the success flage
        return $isSaved;
	}
	//hash password
	function hashPassword($passwordToHash){
		$passwordHash = hash("sha256", $passwordToHash);
		return $passwordHash;
	}
	//attempts to login to a username with a password
	function login($userName, $password){
		$userID = null;
		$checkUserSQL = "SELECT userID FROM users WHERE userName = ? AND password = ?";
		$stmt = $this->db->prepare($checkUserSQL);
		
		$stmt->execute(array($userName, $password)); //, $password
		
		if ($stmt->rowCount() == 1){
			$dataArray = $stmt->fetch(PDO::FETCH_ASSOC);
			echo "success";
			$userID = $dataArray['userID'];
		}else{
			//if login does not return a row
			$this->errors['login'] = "Incorrect username or password";	
		}
		return $userID;
	}
	
	function logout(){
		session_unset();
		session_destroy();
		header('Location: index.php');
		exit;
	}
    
    // validate the data we have stored in the data property
    function validate() {
        // flag as true initially
        $isValid = true;
        
        // if an error, store to errors using column name as key
        
        // validate the data elements in userData property
		//username
        if (empty($this->userData['userName']))
        {
            // if not valid, set an error and flag as not valid
            $this->errors['userName'] = "Please enter a username";
            $isValid = false;
        }else{
			if (strlen($this->userData['userName']) > 20){
				$this->errors['userName'] = "20 character maximum";
				$isValid = false;
			}	
		}
		//password
        if (empty($this->userData['password']))
        {
            // if not valid, set an error and flag as not valid
            $this->errors['password'] = "Please enter a password";
            $isValid = false;
        }                     
        // return valid t/f
        return $isValid;
    }
    
    // get a list of users as an array
    function getList() {
        $userList = array();

        // TODO: get the users and store into $userList

        // load from database
        // create a prepared statement (secure programming)
        $stmt = $this->db->prepare("SELECT * FROM users");
        
        // execute the prepared statement passing in the id of the article we 
        // want to load
        $stmt->execute();

        // check to see if we loaded the article
        if ($stmt->rowCount() > 0) {
			while($row = $stmt->fetch()){
				array_push($userList, $row);
			}
        }
        
        //var_dump($stmt->rowCount());
    
        // return the list of articles
        return $userList;        
    }
	
	function getFilteredList(
		$sortColumn = null,
		$sortDirection = null,
		$filterColumn = null,
		$filterText = null, 
		$page = null){
		
		$userList = array();
		
		$sql = "SELECT * FROM users ";
		
		if (!is_null($filterColumn) && !is_null($filterText)) {
			
			$sql .= " WHERE " . $filterColumn . " LIKE ?";
        }
        
        if (!is_null($sortColumn)) {
            $sql .= " ORDER BY " . $sortColumn;
            
            if (!is_null($sortDirection)) {
                $sql .= " " . $sortDirection;
            }
        }
		//paging config
		if (!is_null($page)){
			$sql .= " LIMIT " . ((2 * $page) - 2) . ",2";
		}
		//paging end
		$stmt = $this->db->prepare($sql);
		
		if ($stmt) {
			$stmt->execute(array('%' . $filterText . '%'));

			$userList = $stmt->fetchAll(PDO::FETCH_ASSOC);
		}
		return $userList;
	}
	function saveImage($fileArray){
	move_uploaded_file($fileArray['tmp_name'], dirname(__FILE__) . 
			"/../public/images/" . $this->userData['userID'] . "_profileImage.jpg");
	}
}

?>
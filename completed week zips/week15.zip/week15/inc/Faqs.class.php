<?php

// class to handle interaction with the newsarticles table
class Faqs {
	
    // property to hold our data from our article
    var $faqData = array();
    // property to hold errors
    var $errors = array();
    // property for holding a reference to a database connection so we can reuse it
    var $db = null;

    function __construct() {
        // create a connection to our database
        $this->db = new PDO('mysql:host=localhost;dbname=wdv441_2021;charset=utf8', 
            'wdv441_user', 'wdv441_2021');           
    }
    
    // takes a keyed array and sets our internal data representation to the array
    function set($dataArray) {
        $this->faqData = $dataArray;
    }

    // santize the data in the passed array, return the array
    function sanitize($dataArray) {
        // sanitize data based on rules
			$dataArray["faqQuestion"] = filter_var($dataArray["faqQuestion"], FILTER_SANITIZE_STRING);
			$dataArray["faqAnswer"] = filter_var($dataArray["faqAnswer"], FILTER_SANITIZE_STRING);
        
        return $dataArray;
    }
    
    // load a news article based on an id
    function load($faqID) {
        // flag to track if the article was loaded
        $isLoaded = false;

        // load from database
        // create a prepared statement (secure programming)
        $stmt = $this->db->prepare("SELECT * FROM faq WHERE faqID = ?");
        
        // execute the prepared statement passing in the id of the article we 
        // want to load
        $stmt->execute(array($faqID));

        // check to see if we loaded the article
        if ($stmt->rowCount() == 1) {
            // if we did load the article, fetch the data as a keyed array
            $dataArray = $stmt->fetch(PDO::FETCH_ASSOC);
            //var_dump($dataArray);
            
            // set the data to our internal property            
            $this->set($dataArray);
                        
            // set the success flag to true
            $isLoaded = true;
        }
        
        //var_dump($stmt->rowCount());
        
        // return success or failure
        return $isLoaded;
    }
    
    // save a news article (inserts and updates)
    function save() {
        // create a flag to track if the save was successful
        $isSaved = false;
        
        // determine if insert or update based on articleID
        // save data from faqData property to database
        if (empty($this->faqData['faqID'])) {
            // create a prepared statement to insert data into the table
            $stmt = $this->db->prepare(
                "INSERT INTO faq 
                    (faqQuestion, faqAnswer) 
                 VALUES (?, ?)"
                 );

            // execute the insert statement, passing in the data to insert
            $isSaved = $stmt->execute(array(
                    $this->faqData['faqQuestion'],
                    $this->faqData['faqAnswer'],

                )
            );
            
            // if the execute returned true, then store the new id back into our 
            // data property
            if ($isSaved) {
                $this->faqData['faqID'] = $this->db->lastInsertId();
            }
        } else { 
			// if this is an update of an existing record, create a prepared update 
			// statement
            $stmt = $this->db->prepare(
                "UPDATE faq SET 
                    faqQuestion = ?,
                    faqAnswer = ?,
                WHERE faqID = ?"
            );
                    
            // execute the update statement, passing in the data to update
            $isSaved = $stmt->execute(array(
                    $this->faqData['faqQuestion'],
                    $this->faqData['faqAnswer'],
                    $this->faqData['faqID']
                )
            );            
        }
                        
        // return the success flage
        return $isSaved;
    }
    
    // validate the data we have stored in the data property
    function validate() {
        // flag as true initially
        $isValid = true;
        
        // if an error, store to errors using column name as key
        
        // validate the data elements in faqData property
		//question
        if (empty($this->faqData['faqQuestion']))
        {
            // if not valid, set an error and flag as not valid
            $this->errors['faqQuestion'] = "Please enter a question";
            $isValid = false;
        }
		//answer
        if (empty($this->faqData['faqAnswer']))
        {
            // if not valid, set an error and flag as not valid
            $this->errors['faqAnswer'] = "Please enter an answer";
            $isValid = false;
        }
        // return valid t/f
        return $isValid;
}
    
    // get a list of news articles as an array
    function getList() {
        $faqList = array();

        // TODO: get the news articles and store into $articleList

        // load from database
        // create a prepared statement (secure programming)
        $stmt = $this->db->prepare("SELECT * FROM faq");
        
        // execute the prepared statement passing in the id of the article we 
        // want to load
        $stmt->execute();

        // check to see if we loaded the article
        if ($stmt->rowCount() > 0) {
			while($row = $stmt->fetch()){
				array_push($faqList, $row);
			}
        }
        
        //var_dump($stmt->rowCount());
    
        // return the list of articles
        return $faqList;        
    }
	
	function getFilteredList($sortColumn = null, $sortDirection = null, $filterColumn = null, $filterText = null){
		$faqList = array();
		$sql = "SELECT * FROM faq ";
		if (!is_null($filterColumn) && !is_null($filterText)) {
			
			$sql .= " WHERE " . $filterColumn . " LIKE ?";
        }
        
        if (!is_null($sortColumn)) {
            $sql .= " ORDER BY " . $sortColumn;
            
            if (!is_null($sortDirection)) {
                $sql .= " " . $sortDirection;
            }
        }
		$stmt = $this->db->prepare($sql);
		
		if ($stmt) {
			$stmt->execute(array('%' . $filterText . '%'));

			$faqList = $stmt->fetchAll(PDO::FETCH_ASSOC);
		}
		return $faqList;
	}
}
?>
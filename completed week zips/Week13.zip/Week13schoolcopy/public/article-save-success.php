<html>
    <body>
        yay!<br>
        <a href="article-list.php">Back to List</a>
    </body>    
</html>
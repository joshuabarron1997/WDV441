<html>
    <body>
        yay!<br>
        <a href="article-list.php">Back to Article List</a>
    </body>    
</html>